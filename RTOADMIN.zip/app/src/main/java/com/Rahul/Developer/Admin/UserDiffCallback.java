package com.Rahul.Developer.Admin;

import androidx.recyclerview.widget.DiffUtil;
import java.util.List;

public class UserDiffCallback extends DiffUtil.Callback {
    private final List<UserData> oldList;
    private final List<UserData> newList;

    public UserDiffCallback(List<UserData> oldList, List<UserData> newList) {
        this.oldList = oldList;
        this.newList = newList;
    }

    @Override
    public int getOldListSize() {
        return oldList.size();
    }

    @Override
    public int getNewListSize() {
        return newList.size();
    }

    @Override
    public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
        return oldList.get(oldItemPosition).getDevice().equals(newList.get(newItemPosition).getDevice());
    }

    @Override
    public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
        return oldList.get(oldItemPosition).equals(newList.get(newItemPosition));
    }
}