package com.Rahul.Developer.Admin;

public class SMSModel {
    private String address;
    private String body;
    private String date;
    private String key; 
    private String userId;

    public SMSModel() {
    }

    public SMSModel(String address, String body, String date, String userId) {
        this.address = address;
        this.body = body;
        this.date = date;
        this.userId = userId;
    }

    public String getSender() {
        return address;
    }

    public String getBody() {
        return body;
    }

    public String getDate() {
        return date;
    }

    public String getKey() {
        return key;
    }

    public String getUserId() {
        return userId;
    }

    public void setSender(String address) {
        this.address = address;
    }

    public void setBody(String body) {
        this.body = body;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}