package com.Rahul.Developer.Admin;

public class UserData {
    private String device;
    private String d_name;
    private int battery;
    private long lastUpdated;
    private String TimeandDate;
    private int user_serial; // নতুন ফিল্ড

    public UserData() {
    }

    public UserData(String device, String d_name, int battery, long lastUpdated, String timeandDate, int user_serial) {
        this.device = device;
        this.d_name = d_name;
        this.battery = battery;
        this.lastUpdated = lastUpdated;
        this.TimeandDate = timeandDate;
        this.user_serial = user_serial;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }

    public String getD_name() {
        return d_name;
    }

    public void setD_name(String d_name) {
        this.d_name = d_name;
    }

    public int getBattery() {
        return battery;
    }

    public void setBattery(int battery) {
        this.battery = battery;
    }

    public long getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(long lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public String getTimeandDate() {
        return TimeandDate;
    }

    public void setTimeandDate(String timeandDate) {
        this.TimeandDate = timeandDate;
    }

    public int getUser_serial() {
        return user_serial;
    }

    public void setUser_serial(int user_serial) {
        this.user_serial = user_serial;
    }
}