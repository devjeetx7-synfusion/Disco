package com.Rahul.Developer.Admin;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;

import java.util.List;

public class SMSAdapter extends BaseAdapter {
    private Context context;
    private List<SMSModel> smsList;
    private DatabaseReference dbRef;

    public SMSAdapter(Context context, List<SMSModel> smsList, DatabaseReference dbRef) {
        this.context = context;
        this.smsList = smsList;
        this.dbRef = dbRef;
    }

    @Override
    public int getCount() {
        return smsList.size();
    }

    @Override
    public Object getItem(int position) {
        return smsList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.sms_item, parent, false);
        }

        TextView sender = convertView.findViewById(R.id.smsSender);
        ImageView delete = convertView.findViewById(R.id.imageview2);
        ImageView copy = convertView.findViewById(R.id.imageview1);
        TextView body = convertView.findViewById(R.id.smsBody);
        TextView date = convertView.findViewById(R.id.smsDate);
        LinearLayout linear1 = convertView.findViewById(R.id.linear1);
        
        linear1.setBackground(new GradientDrawable() {{
            setCornerRadius(18);
            setColor(0xFFBDBDBD);
        }});

        SMSModel sms = smsList.get(position);

        sender.setText("From: " + sms.getSender());
        body.setText("Message: " + sms.getBody());
        date.setText("Date: " + sms.getDate());

        copy.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clip = ClipData.newPlainText("SMS", sms.getBody());
            clipboard.setPrimaryClip(clip);
            Toast.makeText(context, "Message Copied!", Toast.LENGTH_SHORT).show();
        });

delete.setOnClickListener(v -> {
    String smsKey = sms.getKey();
    if (smsKey != null) {
        dbRef.child(smsKey).removeValue().addOnSuccessListener(aVoid -> {
            smsList.remove(sms);
            notifyDataSetChanged();
            Toast.makeText(context, "Message Deleted!", Toast.LENGTH_SHORT).show();
        }).addOnFailureListener(e -> {
            Toast.makeText(context, "Failed to delete!", Toast.LENGTH_SHORT).show();
        });
    } else {
        Toast.makeText(context, "Error: No Key Found!", Toast.LENGTH_SHORT).show();
    }
});

        return convertView;
    }
}