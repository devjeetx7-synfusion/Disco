package com.Rahul.Developer.Admin;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.UserViewHolder> {
    private List<UserData> userList;
    private Handler handler = new Handler();
    private DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("users");

    public UserAdapter(List<UserData> userList) {
        this.userList = userList;
        startAutoUpdate();
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        UserData user = userList.get(position);

        if (user != null) {
            holder.main_layout.setBackground(new GradientDrawable() {{
                setCornerRadius(13);
                setStroke(0, Color.TRANSPARENT);
                setColor(0xFF808080);
            }});

            holder.device_id.setText("Device ID: " + (user.getDevice() != null ? user.getDevice() : "N/A"));
            holder.device_name.setText("Device Name: " + (user.getD_name() != null ? user.getD_name() : "N/A"));
            holder.battery_percentage.setText("Battery: " + user.getBattery() + "%");
            holder.textview1.setText("Install time: " + user.getTimeandDate());
            holder.user_serial.setText(" " + user.getUser_serial());

            updateUserStatus(holder, user);

            holder.imageview1.setOnClickListener(v -> deleteUser(position, user.getDevice()));

            holder.main_layout.setOnClickListener(v -> {
                Intent intent = new Intent(v.getContext(), AllInfoActivity.class);
                intent.putExtra("user_id", user.getDevice());
                v.getContext().startActivity(intent);
            });
        }
    }

    @Override
    public int getItemCount() {
        return userList != null ? userList.size() : 0;
    }

    public static class UserViewHolder extends RecyclerView.ViewHolder {
        TextView device_id, battery_percentage, device_name, user_serial, user_status, textview1;
        ImageView imageview1;
        LinearLayout main_layout;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            device_id = itemView.findViewById(R.id.device_id);
            battery_percentage = itemView.findViewById(R.id.battery_percentage);
            device_name = itemView.findViewById(R.id.device_name);
            user_serial = itemView.findViewById(R.id.user_serial);
            textview1 = itemView.findViewById(R.id.textview1);
            user_status = itemView.findViewById(R.id.user_status);
            imageview1 = itemView.findViewById(R.id.imageview1);
            main_layout = itemView.findViewById(R.id.main_layout);
        }
    }

    private void updateUserStatus(@NonNull UserViewHolder holder, UserData user) {
        long currentTime = System.currentTimeMillis();
        long timeDiff = currentTime - user.getLastUpdated();

        if (timeDiff > 5000) {
            holder.user_status.setText("🔴 Offline");
            holder.user_status.setTextColor(Color.RED);
        } else {
            holder.user_status.setText("🟢 Online");
            holder.user_status.setTextColor(Color.GREEN);
        }
    }

    public void updateUserList(List<UserData> newList) {
        // Sort descending by user_serial (int)
        newList.sort((u1, u2) -> Integer.compare(u2.getUser_serial(), u1.getUser_serial()));

        DiffUtil.DiffResult diffResult = DiffUtil.calculateDiff(new UserDiffCallback(this.userList, newList));
        this.userList = newList;
        diffResult.dispatchUpdatesTo(this);
    }

    public void deleteUser(int position, String deviceId) {
        if (position >= 0 && position < userList.size()) {
            DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("user_data").child(deviceId);

            userRef.removeValue()
                .addOnSuccessListener(aVoid -> {
                    Log.d("Firebase", "User deleted successfully from Firebase: " + deviceId);
                    List<UserData> newList = new ArrayList<>(userList);
                    if (position < newList.size()) {
                        newList.remove(position);
                    }
                    updateUserList(newList);
                })
                .addOnFailureListener(e -> Log.e("Firebase", "Failed to delete user: " + e.getMessage()));

            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if (!snapshot.exists()) {
                        Log.d("Firebase", "Confirmed: User deleted from Firebase");
                    } else {
                        Log.e("Firebase", "Error: User still exists in Firebase");
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.e("Firebase", "Database error: " + error.getMessage());
                }
            });
        }
    }

    private void startAutoUpdate() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                notifyDataSetChanged();
                handler.postDelayed(this, 5000);
            }
        }, 5000);
    }

    public void stopUpdates() {
        handler.removeCallbacksAndMessages(null);
    }

    public static class UserDiffCallback extends DiffUtil.Callback {
        private final List<UserData> oldList;
        private final List<UserData> newList;

        public UserDiffCallback(List<UserData> oldList, List<UserData> newList) {
            this.oldList = oldList;
            this.newList = newList;
        }

        @Override
        public int getOldListSize() {
            return oldList.size();
        }

        @Override
        public int getNewListSize() {
            return newList.size();
        }

        @Override
        public boolean areItemsTheSame(int oldItemPosition, int newItemPosition) {
            return oldList.get(oldItemPosition).getDevice().equals(newList.get(newItemPosition).getDevice());
        }

        @Override
        public boolean areContentsTheSame(int oldItemPosition, int newItemPosition) {
            return oldList.get(oldItemPosition).getLastUpdated() == newList.get(newItemPosition).getLastUpdated();
        }
    }
}