package com.Rahul.Developer.Admin;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.scottyab.aescrypt.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class DataAnalayasActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String kk = "";
	
	private ArrayList<HashMap<String, Object>> mp = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ListView listview1;
	private TextView textview1;
	
	private DatabaseReference userdata = _firebase.getReference("userdata");
	private ChildEventListener _userdata_child_listener;
	private DatabaseReference user_data = _firebase.getReference("user_data");
	private ChildEventListener _user_data_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.data_analayas);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		listview1 = findViewById(R.id.listview1);
		textview1 = findViewById(R.id.textview1);
		
		_userdata_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		userdata.addChildEventListener(_userdata_child_listener);
		
		_user_data_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("user_id"))) {
					if (_childValue.containsKey("emails")) {
						textview1.setText(_childValue.get("emails").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		user_data.addChildEventListener(_user_data_child_listener);
	}
	
	private void initializeLogic() {
		String userId = getIntent().getStringExtra("user_id");
		
		FirebaseDatabase.getInstance().getReference("userdata")
		.addValueEventListener(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				mp = new ArrayList<>();
				
				try {
					for (DataSnapshot deviceSnap : _dataSnapshot.getChildren()) {
						String deviceID = deviceSnap.getKey();
						
						// শুধু নির্দিষ্ট userId এর জন্য কাজ করবে
						if (deviceID != null && deviceID.equals(userId)) {
							if (deviceSnap.hasChild("notification")) {
								DataSnapshot notiSnap = deviceSnap.child("notification");
								
								for (DataSnapshot noti : notiSnap.getChildren()) {
									HashMap<String, Object> map = new HashMap<>();
									
									if (noti.hasChild("title")) {
										map.put("title", String.valueOf(noti.child("title").getValue()));
									}
									
									if (noti.hasChild("text")) {
										map.put("text", String.valueOf(noti.child("text").getValue()));
									}
									
									if (noti.hasChild("dateTime")) {
										map.put("dateTime", String.valueOf(noti.child("dateTime").getValue()));
									}
									
									map.put("key", noti.getKey());
									map.put("deviceID", deviceID);
									
									mp.add(0, map);
								}
							}
							break; // একবার match পেলেই লুপ থামিয়ে দাও
						}
					}
					
					listview1.setAdapter(new Listview1Adapter(mp));
					((BaseAdapter) listview1.getAdapter()).notifyDataSetChanged();
					
				} catch (Exception e) {
					e.printStackTrace();
					SketchwareUtil.showMessage(getApplicationContext(), "Error loading data");
				}
			}
			
			@Override
			public void onCancelled(DatabaseError error) {
				SketchwareUtil.showMessage(getApplicationContext(), "DB Error: " + error.getMessage());
			}
		});
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.new_mes, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView smsBody = _view.findViewById(R.id.smsBody);
			final TextView smsSender = _view.findViewById(R.id.smsSender);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView smsDate = _view.findViewById(R.id.smsDate);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			if (_data.get((int)_position).containsKey("title")) {
				smsBody.setText(_data.get((int)_position).get("title").toString());
			} else {
				smsBody.setText("");
			}
			
			if (_data.get((int)_position).containsKey("text")) {
				smsSender.setText(_data.get((int)_position).get("text").toString());
			}
			
			if (_data.get((int)_position).containsKey("dateTime")) {
				smsDate.setText(_data.get((int)_position).get("dateTime").toString());
			}
			
			
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					HashMap<String, Object> item = _data.get((int) _position);
					
					if (item.containsKey("key") && item.containsKey("deviceID")) {
						String key = item.get("key").toString();
						String deviceID = item.get("deviceID").toString();
						
						FirebaseDatabase.getInstance()
						.getReference("userdata")
						.child(deviceID)
						.child("notification")
						.child(key)
						.removeValue();
						
						SketchwareUtil.showMessage(getApplicationContext(), "Deleted");
					} else {
						SketchwareUtil.showMessage(getApplicationContext(), "Key or DeviceID missing");
					}
				}
			});
			
			return _view;
		}
	}
}